//
//  ViewController.swift
//  Rupanagudi_CalculatorApp
//
//  Created by Raghupathi Reddy Rupanagudi on 9/24/23.
//

import UIKit

class ViewController: UIViewController {
    
    var currNumber: Double = 0;
    var prevNumber: Double = 0
    var currOperator: String = ""
    var isNumber = false
    var isNegative = false

    @IBOutlet weak var resultOutlet: UILabel!
    
    
    @IBAction func buttonAllClear(_ sender: UIButton) {
        currNumber = 0
        prevNumber = 0
        currOperator = ""
        resultOutlet.text = " "
        isNumber = false
        isNegative = false
        
    }
    
    
    @IBAction func buttonClear(_ sender: UIButton) {
        
        resultOutlet.text = "0"
        isNumber = false
    }
    
    
    
    @IBAction func buttonAddSub(_ sender: UIButton) {
        
        if isNumber{
            
            isNegative = !isNegative
            if isNegative{
                resultOutlet.text = "-" + resultOutlet.text!
            }else{
                resultOutlet.text!.removeFirst()
            }
        }
        
    }
    
    
    @IBAction func buttonDiv(_ sender: UIButton) {
        calcOperator("÷")
    }
    
    
    
    
    @IBAction func buttonMul(_ sender: UIButton) {
        
      calcOperator("X")
    }
    
    @IBAction func buttonSub(_ sender: UIButton) {
        
        calcOperator("-")
    }
    
    
    @IBAction func buttonAdd(_ sender: UIButton) {
        
        calcOperator("+")
    }
    
    @IBAction func buttonEquals(_ sender: UIButton) {
        
        if isNumber {
            let operand1 = Double(resultOutlet.text!) ??  0
            switch currOperator{
            case "+":
                currNumber += operand1
            
            case "-":
                currNumber -= operand1
                
            case "X":
                currNumber *= operand1
                
            case "÷":
                if operand1 != 0 {
                    currNumber /= operand1
                } else {
                    resultOutlet.text = "Not a number"
                    return
                }
            case "%":
                currNumber = currNumber.truncatingRemainder(dividingBy: operand1)
            default:
                break
            }
            resultOutlet.text = result(currNumber)
            
            isNumber = false
            isNegative = false
        }
    }
    
    
    @IBAction func buttonMod(_ sender: UIButton) {
        calcOperator("%")
    }
    
    @IBAction func buttonDec(_ sender: UIButton) {
        
        if isNumber && !resultOutlet.text!.contains("."){
            resultOutlet.text! += "." }
        else if !isNumber{
            resultOutlet.text = "."
            isNumber = true
            
        }
    }
    @IBAction func Seven(_ sender: UIButton) {
       calcDigit(7)

    }
    @IBAction func Eight(_ sender: UIButton) {
        calcDigit(8)

    }
    @IBAction func Nine(_ sender: UIButton) {
        calcDigit(9)

    }
    @IBAction func Four(_ sender: UIButton) {
        calcDigit(4)

    }
    @IBAction func Five(_ sender: UIButton) {
        calcDigit(5)

    }
    @IBAction func Six(_ sender: UIButton) {
        calcDigit(6)

    }
    @IBAction func One(_ sender: UIButton) {
        calcDigit(1)

    }
    @IBAction func Two(_ sender: UIButton) {
        calcDigit(2)

    }
    @IBAction func Three(_ sender: UIButton) {
        calcDigit(3)

    }
    @IBAction func Zero(_ sender: UIButton) {
        calcDigit(0)

    }
   
    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }
    
    func calcDigit(_ num: Int) {
        if isNumber {
            if resultOutlet.text == "0" || resultOutlet.text == "-0" {
                if num != 0 {
                    resultOutlet.text = isNegative ? "-" + "\(num)" : "\(num)"
                }
            }else {
                resultOutlet.text! += "\(num)"
            }
        }else {
            resultOutlet.text = isNegative ? "-" + "\(num)":"\(num)"
            isNumber = true
            
                }
            }
    
    func calcOperator(_ operatorSign : String) {
        if isNumber{
            let currentInput = resultOutlet.text!
            currNumber = Double(currentInput) ?? 0
            isNumber = false
        }
        currOperator = operatorSign
        isNegative = false
    }
    
    func result(_ num1: Double) -> String{
    let enteredNumber = round(num1 * 100000) / 100000
        if enteredNumber.truncatingRemainder(dividingBy: 1) == 0 {
            return String(format: "%.0f" , enteredNumber)
        } else {
            return String(enteredNumber);
        }
    }
}
    

